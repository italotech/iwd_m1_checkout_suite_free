<?php

class IWD_Opc_Block_Onepage_Payment_Discount extends Mage_Checkout_Block_Cart_Coupon
{

}
