<?php

class IWD_Opc_Block_Onepage_Payment_Giftcard_Opc extends Mage_Core_Block_Template
{

    public function _toHtml()
    {
        return '';
    }
}