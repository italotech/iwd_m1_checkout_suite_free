<?php

class IWD_Opc_Block_Onepage_Review_Renderer_Tax extends Mage_Tax_Block_Checkout_Tax
{

    protected $_template = 'iwd/opc/onepage/review/totals/tax.phtml';

}
