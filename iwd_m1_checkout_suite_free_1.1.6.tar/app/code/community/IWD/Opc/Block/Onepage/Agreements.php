<?php

class IWD_Opc_Block_Onepage_Agreements extends Mage_Checkout_Block_Agreements
{

}
