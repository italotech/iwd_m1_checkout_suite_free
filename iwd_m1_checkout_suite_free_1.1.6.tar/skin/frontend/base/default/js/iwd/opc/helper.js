;
Validation.add('required-entry', 'This is a required field.', function (v, elm) {
    var isValid = !Validation.get('IsEmpty').test(v);
    if (isValid) {
        $ji(elm).closest('.iwd_opc_universal_wrapper').removeClass('iwd_opc_empty_field');
    } else {
        $ji(elm).closest('.iwd_opc_universal_wrapper').addClass('iwd_opc_empty_field');
    }

    return isValid;
});

Validation.add('validate-select', 'Please select an option.', function (v, elm) {
    var isValid = ((v != "none") && (v != null) && (v.length != 0));
    if (isValid) {
        $ji(elm).closest('.iwd_opc_universal_wrapper').removeClass('iwd_opc_empty_field');
    } else {
        $ji(elm).closest('.iwd_opc_universal_wrapper').addClass('iwd_opc_empty_field');
    }

    return isValid;
});

Validation.add('validate-iwd-opc-cpassword', 'Please make sure your passwords match.', function (v, elm) {
    var pass = false;
    var passwordElements = $$('.validate-password');
    for (var i = 0; i < passwordElements.size(); i++) {
        var passwordElement = passwordElements[i];
        if (passwordElement.up('form').id == elm.up('form').id) {
            pass = passwordElement;
        }
    }

    return (pass.value == v);
});

Validation.add('validate-iwd-opc-cc-exp', 'Incorrect credit card expiration date.', function (v, elm) {
    var ccExpMonthYearArr = v.split('/');
    var is_valid = false;
    if (ccExpMonthYearArr[0] && ccExpMonthYearArr[1]) {
        var ccExpMonth = parseInt(ccExpMonthYearArr[0]);
        var ccExpYear = parseInt(ccExpMonthYearArr[1]);
        var currentTime = new Date();
        var currentMonth = currentTime.getMonth() + 1;
        var currentYear = currentTime.getFullYear();
        if (ccExpMonth > 12) {
            is_valid = false;
        } else if (ccExpYear > currentYear) {
            is_valid = true;
        } else if (ccExpMonth >= currentMonth && ccExpYear == currentYear) {
            is_valid = true;
        }

        // if (is_valid) {
        //     Singleton.get(PaymentMethod).fillCcExpDateFields(elm, ccExpMonth, ccExpYear);
        // }
    }

    // if (!is_valid) {
    //     Singleton.get(PaymentMethod).fillCcExpDateFields(elm, '', '');
    // }

    return is_valid;
});

Validation.add('validate-iwd-opc-cc-number', 'Please enter a valid credit card number.', function (v, elm) {
    v = v.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    return validateCreditCard(v);
});

Validation.add('validate-iwd-opc-cc-type', 'Credit card number does not match credit card type.', function (v, elm) {
    v = v.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    var ccTypeContainer = $ji(elm).closest('.iwd_opc_universal_wrapper').find('.iwd_opc_select[name="payment[cc_type]"]');
    if (!ccTypeContainer.length) {
        ccTypeContainer = $ji(elm).closest('.iwd_opc_universal_wrapper').find('.iwd_opc_select[data-name="payment[cc_type]"]');
    }

    if (!ccTypeContainer.length) {
        return true;
    }

    var ccType = ccTypeContainer.val();

    if (typeof (Singleton.get(PaymentMethod).ccTypes[ccType]) == 'undefined') {
        return false;
    }

    if (Singleton.get(PaymentMethod).ccTypes[ccType][0] == false) {
        return true;
    }

    var ccRegex = Singleton.get(PaymentMethod).ccTypes[ccType][0];
    return v.match(ccRegex);
});

Validation.add('validate-iwd-opc-cvv', 'Please enter a valid credit card verification number.', function (v, elm) {
    var ccTypeContainer = $ji(elm).closest('.iwd_opc_payment_method_form').find('.iwd_opc_select[name="payment[cc_type]"]');
    if (!ccTypeContainer.length) {
        ccTypeContainer = $ji(elm).closest('.iwd_opc_universal_wrapper').find('.iwd_opc_select[data-name="payment[cc_type]"]');
    }

    if (!ccTypeContainer.length) {
        return true;
    }

    var ccType = ccTypeContainer.val();
    if (typeof (Singleton.get(PaymentMethod).ccTypes[ccType]) == 'undefined') {
        return false;
    }

    var re = Singleton.get(PaymentMethod).ccTypes[ccType][1];
    return v.match(re);
});

Array.prototype.remove = function () {
    var what, a = arguments, L = a.length, ax;
    while (L && this.length) {
        what = a[--L];
        while ((ax = this.indexOf(what)) !== -1) {
            this.splice(ax, 1);
        }
    }
    return this;
};

(function ($) {
    $.fn.addBack = $.fn.addBack || $.fn.andSelf;

    $.fn.extend({

        actualScrollHeight: function () {
            var $target = this.eq(0);
            var fix, restore;
            var tmp = [];
            var style = '';
            var $hidden;
            var $this = $(this);
            fix = function () {
                // get all hidden parents
                $hidden = $target.parents().addBack().filter(':hidden');
                style += 'visibility: hidden !important; display: block !important; ';


                $hidden.each(function () {
                    var $this = $(this);
                    var thisStyle = $this.attr('style');

                    tmp.push(thisStyle);
                    $this.attr('style', thisStyle ? thisStyle + ';' + style : style);
                });
            };

            restore = function () {
                // restore origin style values
                $hidden.each(function (i) {
                    var $this = $(this);
                    var _tmp = tmp[i];

                    if (_tmp === undefined) {
                        $this.removeAttr('style');
                    } else {
                        $this.attr('style', _tmp);
                    }
                });
            };

            fix();
            var actual = $target.get(0).scrollHeight;
            restore();

            return actual;
        }
    });
})($ji);

(function ($) {
    'use strict';

    // init flags & variables
    var debug = false;

    var browser = {
        data: {
            index: 0,
            name: 'scrollbar'
        },
        firefox: /firefox/i.test(navigator.userAgent),
        macosx: /mac/i.test(navigator.platform),
        msedge: /edge\/\d+/i.test(navigator.userAgent),
        msie: /(msie|trident)/i.test(navigator.userAgent),
        mobile: /android|webos|iphone|ipad|ipod|blackberry/i.test(navigator.userAgent),
        overlay: null,
        scroll: null,
        scrolls: [],
        webkit: /webkit/i.test(navigator.userAgent) && !/edge\/\d+/i.test(navigator.userAgent)
    };

    browser.scrolls.add = function (instance) {
        this.remove(instance).push(instance);
    };
    browser.scrolls.remove = function (instance) {
        while ($.inArray(instance, this) >= 0) {
            this.splice($.inArray(instance, this), 1);
        }
        return this;
    };

    var defaults = {
        autoScrollSize: true, // automatically calculate scrollsize
        autoUpdate: true, // update scrollbar if content/container size changed
        debug: false, // debug mode
        disableBodyScroll: false, // disable body scroll if mouse over container
        duration: 150, // scroll animate duration in ms
        ignoreMobile: false, // ignore mobile devices
        ignoreOverlay: false, // ignore browsers with overlay scrollbars (mobile, MacOS)
        isRtl: false, // is RTL
        scrollStep: 60, // scroll step for scrollbar arrows
        showArrows: false, // add class to show arrows
        stepScrolling: true, // when scrolling to scrollbar mousedown position

        scrollx: null, // horizontal scroll element
        scrolly: null, // vertical scroll element

        onDestroy: null, // callback function on destroy,
        onFallback: null, // callback function if scrollbar is not initialized
        onInit: null, // callback function on first initialization
        onScroll: null, // callback function on content scrolling
        onUpdate: null            // callback function on init/resize (before scrollbar size calculation)
    };


    var BaseScrollbar = function (container) {

        if (!browser.scroll) {
            browser.overlay = isScrollOverlaysContent();
            browser.scroll = getBrowserScrollSize();
            updateScrollbars();

            $(window).resize(function () {
                var forceUpdate = false;
                if (browser.scroll && (browser.scroll.height || browser.scroll.width)) {
                    var scroll = getBrowserScrollSize();
                    if (scroll.height !== browser.scroll.height || scroll.width !== browser.scroll.width) {
                        browser.scroll = scroll;
                        forceUpdate = true; // handle page zoom
                    }
                }
                updateScrollbars(forceUpdate);
            });
        }

        this.container = container;
        this.namespace = '.scrollbar_' + browser.data.index++;
        this.options = $.extend({}, defaults, window.jQueryScrollbarOptions || {});
        this.scrollTo = null;
        this.scrollx = {};
        this.scrolly = {};

        container.data(browser.data.name, this);
        browser.scrolls.add(this);
    };

    BaseScrollbar.prototype = {
        destroy: function () {

            if (!this.wrapper) {
                return;
            }

            this.container.removeData(browser.data.name);
            browser.scrolls.remove(this);

            // init variables
            var scrollLeft = this.container.scrollLeft();
            var scrollTop = this.container.scrollTop();

            this.container.insertBefore(this.wrapper).css({
                "height": "",
                "margin": "",
                "max-height": ""
            })
                .removeClass('scroll-content scroll-scrollx_visible scroll-scrolly_visible')
                .off(this.namespace)
                .scrollLeft(scrollLeft)
                .scrollTop(scrollTop);

            this.scrollx.scroll.removeClass('scroll-scrollx_visible').find('div').addBack().off(this.namespace);
            this.scrolly.scroll.removeClass('scroll-scrolly_visible').find('div').addBack().off(this.namespace);

            this.wrapper.remove();

            $(document).add('body').off(this.namespace);

            if ($.isFunction(this.options.onDestroy)) {
                this.options.onDestroy.apply(this, [this.container]);
            }
        },
        init: function (options) {

            // init variables
            var S = this,
                c = this.container,
                cw = this.containerWrapper || c,
                namespace = this.namespace,
                o = $.extend(this.options, options || {}),
                s = {x: this.scrollx, y: this.scrolly},
                w = this.wrapper,
                cssOptions = {};

            var initScroll = {
                scrollLeft: c.scrollLeft(),
                scrollTop: c.scrollTop()
            };

            // do not init if in ignorable browser
            if ((browser.mobile && o.ignoreMobile)
                || (browser.overlay && o.ignoreOverlay)
                || (browser.macosx && !browser.webkit) // still required to ignore nonWebKit browsers on Mac
            ) {
                if ($.isFunction(o.onFallback)) {
                    o.onFallback.apply(this, [c]);
                }
                return false;
            }

            // init scroll container
            if (!w) {
                this.wrapper = w = $('<div>').addClass('scroll-wrapper')
                // .addClass(c.attr('class'))
                    .attr('tabindex', -1)
                    .css('position', c.css('position') === 'absolute' ? 'absolute' : 'relative')
                    .insertBefore(c).append(c);

                if (o.isRtl) {
                    w.addClass('scroll--rtl');
                }

                if (c.is('textarea')) {
                    this.containerWrapper = cw = $('<div>').insertBefore(c).append(c);
                    w.addClass('scroll-textarea');
                }

                cssOptions = {
                    "height": "auto",
                    "margin-bottom": browser.scroll.height * -1 + 'px',
                    "max-height": ""
                };
                cssOptions[o.isRtl ? 'margin-left' : 'margin-right'] = browser.scroll.width * -1 + 'px';

                cw.addClass('scroll-content').css(cssOptions);

                c.on('scroll' + namespace, function (event) {
                    var scrollLeft = c.scrollLeft();
                    var scrollTop = c.scrollTop();
                    if (o.isRtl) {
                        // webkit   0:100
                        // ie/edge  100:0
                        // firefox -100:0
                        switch (true) {
                            case browser.firefox:
                                scrollLeft = Math.abs(scrollLeft);
                            case browser.msedge || browser.msie:
                                scrollLeft = c[0].scrollWidth - c[0].clientWidth - scrollLeft;
                                break;
                        }
                    }
                    if ($.isFunction(o.onScroll)) {
                        o.onScroll.call(S, {
                            maxScroll: s.y.maxScrollOffset,
                            scroll: scrollTop,
                            size: s.y.size,
                            visible: s.y.visible
                        }, {
                            maxScroll: s.x.maxScrollOffset,
                            scroll: scrollLeft,
                            size: s.x.size,
                            visible: s.x.visible
                        });
                    }
                    s.x.isVisible && s.x.scroll.bar.css('left', scrollLeft * s.x.kx + 'px');
                    s.y.isVisible && s.y.scroll.bar.css('top', scrollTop * s.y.kx + 'px');
                });

                c.on('keydown', function (event) {
                    var scrollLeft = c.scrollLeft();
                    var scrollTop = c.scrollTop();
                    s.x.isVisible && s.x.scroll.bar.css('left', scrollLeft * s.x.kx + 'px');
                    s.y.isVisible && s.y.scroll.bar.css('top', scrollTop * s.y.kx + 'px');
                });

                /* prevent native scrollbars to be visible on #anchor click */
                w.on('scroll' + namespace, function () {
                    w.scrollTop(0).scrollLeft(0);
                });

                if (o.disableBodyScroll) {
                    var handleMouseScroll = function (event) {
                        isVerticalScroll(event) ?
                        s.y.isVisible && s.y.mousewheel(event) :
                        s.x.isVisible && s.x.mousewheel(event);
                    };
                    w.on('MozMousePixelScroll' + namespace, handleMouseScroll);
                    w.on('mousewheel' + namespace, handleMouseScroll);

                    if (browser.mobile) {
                        w.on('touchstart' + namespace, function (event) {
                            var touch = event.originalEvent.touches && event.originalEvent.touches[0] || event;
                            var originalTouch = {
                                pageX: touch.pageX,
                                pageY: touch.pageY
                            };
                            var originalScroll = {
                                left: c.scrollLeft(),
                                top: c.scrollTop()
                            };
                            $(document).on('touchmove' + namespace, function (event) {
                                var touch = event.originalEvent.targetTouches && event.originalEvent.targetTouches[0] || event;
                                c.scrollLeft(originalScroll.left + originalTouch.pageX - touch.pageX);
                                c.scrollTop(originalScroll.top + originalTouch.pageY - touch.pageY);
                                event.preventDefault();
                            });
                            $(document).on('touchend' + namespace, function () {
                                $(document).off(namespace);
                            });
                        });
                    }
                }
                if ($.isFunction(o.onInit)) {
                    o.onInit.apply(this, [c]);
                }
            } else {
                cssOptions = {
                    "height": "auto",
                    "margin-bottom": browser.scroll.height * -1 + 'px',
                    "max-height": ""
                };
                cssOptions[o.isRtl ? 'margin-left' : 'margin-right'] = browser.scroll.width * -1 + 'px';
                cw.css(cssOptions);
            }

            // init scrollbars & recalculate sizes
            $.each(s, function (d, scrollx) {

                var scrollCallback = null;
                var scrollForward = 1;
                var scrollOffset = (d === 'x') ? 'scrollLeft' : 'scrollTop';
                var scrollStep = o.scrollStep;
                var scrollTo = function () {
                    var currentOffset = c[scrollOffset]();
                    c[scrollOffset](currentOffset + scrollStep);
                    if (scrollForward == 1 && (currentOffset + scrollStep) >= scrollToValue)
                        currentOffset = c[scrollOffset]();
                    if (scrollForward == -1 && (currentOffset + scrollStep) <= scrollToValue)
                        currentOffset = c[scrollOffset]();
                    if (c[scrollOffset]() == currentOffset && scrollCallback) {
                        scrollCallback();
                    }
                }
                var scrollToValue = 0;

                if (!scrollx.scroll) {

                    scrollx.scroll = S._getScroll(o['scroll' + d]).addClass('scroll-' + d);

                    if (o.showArrows) {
                        scrollx.scroll.addClass('scroll-element_arrows_visible');
                    }

                    scrollx.mousewheel = function (event) {

                        if (!scrollx.isVisible || (d === 'x' && isVerticalScroll(event))) {
                            return true;
                        }
                        if (d === 'y' && !isVerticalScroll(event)) {
                            s.x.mousewheel(event);
                            return true;
                        }

                        var delta = event.originalEvent.wheelDelta * -1 || event.originalEvent.detail;
                        var maxScrollValue = scrollx.size - scrollx.visible - scrollx.offset;

                        // fix new mozilla
                        if (!delta) {
                            if (d === 'x' && !!event.originalEvent.deltaX) {
                                delta = event.originalEvent.deltaX * 40;
                            } else if (d === 'y' && !!event.originalEvent.deltaY) {
                                delta = event.originalEvent.deltaY * 40;
                            }
                        }

                        if ((delta > 0 && scrollToValue < maxScrollValue) || (delta < 0 && scrollToValue > 0)) {
                            scrollToValue = scrollToValue + delta;
                            if (scrollToValue < 0)
                                scrollToValue = 0;
                            if (scrollToValue > maxScrollValue)
                                scrollToValue = maxScrollValue;

                            S.scrollTo = S.scrollTo || {};
                            S.scrollTo[scrollOffset] = scrollToValue;
                            setTimeout(function () {
                                if (S.scrollTo) {
                                    c.stop().animate(S.scrollTo, 240, 'linear', function () {
                                        scrollToValue = c[scrollOffset]();
                                    });
                                    S.scrollTo = null;
                                }
                            }, 1);
                        }

                        event.preventDefault();
                        return false;
                    };

                    scrollx.scroll
                        .on('MozMousePixelScroll' + namespace, scrollx.mousewheel)
                        .on('mousewheel' + namespace, scrollx.mousewheel)
                        .on('mouseenter' + namespace, function () {
                            scrollToValue = c[scrollOffset]();
                        });

                    // handle arrows & scroll inner mousedown event
                    scrollx.scroll.find('.scroll-arrow, .scroll-element_track')
                        .on('mousedown' + namespace, function (event) {

                            if (event.which != 1) // lmb
                                return true;

                            scrollForward = 1;

                            var data = {
                                eventOffset: event[(d === 'x') ? 'pageX' : 'pageY'],
                                maxScrollValue: scrollx.size - scrollx.visible - scrollx.offset,
                                scrollbarOffset: scrollx.scroll.bar.offset()[(d === 'x') ? 'left' : 'top'],
                                scrollbarSize: scrollx.scroll.bar[(d === 'x') ? 'outerWidth' : 'outerHeight']()
                            };
                            var timeout = 0, timer = 0;

                            if ($(this).hasClass('scroll-arrow')) {
                                scrollForward = $(this).hasClass("scroll-arrow_more") ? 1 : -1;
                                scrollStep = o.scrollStep * scrollForward;
                                scrollToValue = scrollForward > 0 ? data.maxScrollValue : 0;
                                if (o.isRtl) {
                                    switch (true) {
                                        case browser.firefox:
                                            scrollToValue = scrollForward > 0 ? 0 : data.maxScrollValue * -1;
                                            break;
                                        case browser.msie || browser.msedge:
                                            break;
                                    }
                                }
                            } else {
                                scrollForward = (data.eventOffset > (data.scrollbarOffset + data.scrollbarSize) ? 1
                                    : (data.eventOffset < data.scrollbarOffset ? -1 : 0));
                                if (d === 'x' && o.isRtl && (browser.msie || browser.msedge))
                                    scrollForward = scrollForward * -1;
                                scrollStep = Math.round(scrollx.visible * 0.75) * scrollForward;
                                scrollToValue = (data.eventOffset - data.scrollbarOffset -
                                (o.stepScrolling ? (scrollForward == 1 ? data.scrollbarSize : 0)
                                    : Math.round(data.scrollbarSize / 2)));
                                scrollToValue = c[scrollOffset]() + (scrollToValue / scrollx.kx);
                            }

                            S.scrollTo = S.scrollTo || {};
                            S.scrollTo[scrollOffset] = o.stepScrolling ? c[scrollOffset]() + scrollStep : scrollToValue;

                            if (o.stepScrolling) {
                                scrollCallback = function () {
                                    scrollToValue = c[scrollOffset]();
                                    clearInterval(timer);
                                    clearTimeout(timeout);
                                    timeout = 0;
                                    timer = 0;
                                };
                                timeout = setTimeout(function () {
                                    timer = setInterval(scrollTo, 40);
                                }, o.duration + 100);
                            }

                            setTimeout(function () {
                                if (S.scrollTo) {
                                    c.animate(S.scrollTo, o.duration);
                                    S.scrollTo = null;
                                }
                            }, 1);

                            return S._handleMouseDown(scrollCallback, event);
                        });

                    // handle scrollbar drag'n'drop
                    scrollx.scroll.bar.on('mousedown' + namespace, function (event) {

                        if (event.which != 1) // lmb
                            return true;

                        var eventPosition = event[(d === 'x') ? 'pageX' : 'pageY'];
                        var initOffset = c[scrollOffset]();

                        scrollx.scroll.addClass('scroll-draggable');

                        $(document).on('mousemove' + namespace, function (event) {
                            var diff = parseInt((event[(d === 'x') ? 'pageX' : 'pageY'] - eventPosition) / scrollx.kx, 10);
                            if (d === 'x' && o.isRtl && (browser.msie || browser.msedge))
                                diff = diff * -1;
                            c[scrollOffset](initOffset + diff);
                        });

                        return S._handleMouseDown(function () {
                            scrollx.scroll.removeClass('scroll-draggable');
                            scrollToValue = c[scrollOffset]();
                        }, event);
                    });
                }
            });

            // remove classes & reset applied styles
            $.each(s, function (d, scrollx) {
                var scrollClass = 'scroll-scroll' + d + '_visible';
                var scrolly = (d == "x") ? s.y : s.x;

                scrollx.scroll.removeClass(scrollClass);
                scrolly.scroll.removeClass(scrollClass);
                cw.removeClass(scrollClass);
            });

            // calculate init sizes
            $.each(s, function (d, scrollx) {
                $.extend(scrollx, (d == "x") ? {
                    offset: parseInt(c.css('left'), 10) || 0,
                    size: c.prop('scrollWidth'),
                    visible: w.width()
                } : {
                    offset: parseInt(c.css('top'), 10) || 0,
                    size: c.prop('scrollHeight'),
                    visible: w.height()
                });
            });

            // update scrollbar visibility/dimensions
            this._updateScroll('x', this.scrollx);
            this._updateScroll('y', this.scrolly);

            if ($.isFunction(o.onUpdate)) {
                o.onUpdate.apply(this, [c]);
            }

            // calculate scroll size
            $.each(s, function (d, scrollx) {

                var cssOffset = (d === 'x') ? 'left' : 'top';
                var cssFullSize = (d === 'x') ? 'outerWidth' : 'outerHeight';
                var cssSize = (d === 'x') ? 'width' : 'height';
                var offset = parseInt(c.css(cssOffset), 10) || 0;

                var AreaSize = scrollx.size;
                var AreaVisible = scrollx.visible + offset;

                var scrollSize = scrollx.scroll.size[cssFullSize]() + (parseInt(scrollx.scroll.size.css(cssOffset), 10) || 0);

                if (o.autoScrollSize) {
                    scrollx.scrollbarSize = parseInt(scrollSize * AreaVisible / AreaSize, 10);
                    scrollx.scroll.bar.css(cssSize, scrollx.scrollbarSize + 'px');
                }

                scrollx.scrollbarSize = scrollx.scroll.bar[cssFullSize]();
                scrollx.kx = ((scrollSize - scrollx.scrollbarSize) / (AreaSize - AreaVisible)) || 1;
                scrollx.maxScrollOffset = AreaSize - AreaVisible;
            });

            c.scrollLeft(initScroll.scrollLeft).scrollTop(initScroll.scrollTop).trigger('scroll');
        },
        /**
         * Get scrollx/scrolly object
         *
         * @param {Mixed} scroll
         * @returns {jQuery} scroll object
         */
        _getScroll: function (scroll) {
            var types = {
                advanced: [
                    '<div class="scroll-element">',
                    '<div class="scroll-element_corner"></div>',
                    '<div class="scroll-arrow scroll-arrow_less"></div>',
                    '<div class="scroll-arrow scroll-arrow_more"></div>',
                    '<div class="scroll-element_outer">',
                    '<div class="scroll-element_size"></div>', // required! used for scrollbar size calculation !
                    '<div class="scroll-element_inner-wrapper">',
                    '<div class="scroll-element_inner scroll-element_track">', // used for handling scrollbar click
                    '<div class="scroll-element_inner-bottom"></div>',
                    '</div>',
                    '</div>',
                    '<div class="scroll-bar">', // required
                    '<div class="scroll-bar_body">',
                    '<div class="scroll-bar_body-inner"></div>',
                    '</div>',
                    '<div class="scroll-bar_bottom"></div>',
                    '<div class="scroll-bar_center"></div>',
                    '</div>',
                    '</div>',
                    '</div>'
                ].join(''),
                simple: [
                    '<div class="scroll-element">',
                    '<div class="scroll-element_outer">',
                    '<div class="scroll-element_size"></div>', // required! used for scrollbar size calculation !
                    '<div class="scroll-element_track"></div>', // used for handling scrollbar click
                    '<div class="scroll-bar"></div>', // required
                    '</div>',
                    '</div>'
                ].join('')
            };
            if (types[scroll]) {
                scroll = types[scroll];
            }
            if (!scroll) {
                scroll = types['simple'];
            }
            if (typeof (scroll) == 'string') {
                scroll = $(scroll).appendTo(this.wrapper);
            } else {
                scroll = $(scroll);
            }
            $.extend(scroll, {
                bar: scroll.find('.scroll-bar'),
                size: scroll.find('.scroll-element_size'),
                track: scroll.find('.scroll-element_track')
            });
            return scroll;
        },
        _handleMouseDown: function (callback, event) {

            var namespace = this.namespace;

            $(document).on('blur' + namespace, function () {
                $(document).add('body').off(namespace);
                callback && callback();
            });
            $(document).on('dragstart' + namespace, function (event) {
                event.preventDefault();
                return false;
            });
            $(document).on('mouseup' + namespace, function () {
                $(document).add('body').off(namespace);
                callback && callback();
            });
            $('body').on('selectstart' + namespace, function (event) {
                event.preventDefault();
                return false;
            });

            event && event.preventDefault();
            return false;
        },
        _updateScroll: function (d, scrollx) {

            var container = this.container,
                containerWrapper = this.containerWrapper || container,
                scrollClass = 'scroll-scroll' + d + '_visible',
                scrolly = (d === 'x') ? this.scrolly : this.scrollx,
                offset = parseInt(this.container.css((d === 'x') ? 'left' : 'top'), 10) || 0,
                wrapper = this.wrapper;

            var AreaSize = scrollx.size;
            var AreaVisible = scrollx.visible + offset;

            scrollx.isVisible = (AreaSize - AreaVisible) > 1; // bug in IE9/11 with 1px diff
            if (scrollx.isVisible) {
                scrollx.scroll.addClass(scrollClass);
                scrolly.scroll.addClass(scrollClass);
                containerWrapper.addClass(scrollClass);
            } else {
                scrollx.scroll.removeClass(scrollClass);
                scrolly.scroll.removeClass(scrollClass);
                containerWrapper.removeClass(scrollClass);
            }

            if (d === 'y') {
                if (container.is('textarea') || AreaSize < AreaVisible) {
                    containerWrapper.css({
                        "height": (AreaVisible + browser.scroll.height + browser.scroll.height) + 'px',
                        "max-height": "none"
                    });
                } else {
                    containerWrapper.css({
                        // "height": "auto", // do not reset height value: issue with height:100%!
                        "max-height": (AreaVisible + browser.scroll.height + browser.scroll.height) + 'px',
                        // "height": (AreaVisible) + 'px'
                    });
                }
            }

            if (scrollx.size != container.prop('scrollWidth')
                || scrolly.size != container.prop('scrollHeight')
                || scrollx.visible != wrapper.width()
                || scrolly.visible != wrapper.height()
                || scrollx.offset != (parseInt(container.css('left'), 10) || 0)
                || scrolly.offset != (parseInt(container.css('top'), 10) || 0)
            ) {
                $.extend(this.scrollx, {
                    offset: parseInt(container.css('left'), 10) || 0,
                    size: container.prop('scrollWidth'),
                    visible: wrapper.width()
                });
                $.extend(this.scrolly, {
                    offset: parseInt(container.css('top'), 10) || 0,
                    size: this.container.prop('scrollHeight'),
                    visible: wrapper.height()
                });
                this._updateScroll(d === 'x' ? 'y' : 'x', scrolly);
            }
        }
    };

    var CustomScrollbar = BaseScrollbar;

    /*
     * Extend jQuery as plugin
     *
     * @param {Mixed} command to execute
     * @param {Mixed} arguments as Array
     * @return {jQuery}
     */
    $.fn.scrollbar = function (command, args) {
        if (typeof command !== 'string') {
            args = command;
            command = 'init';
        }
        if (typeof args === 'undefined') {
            args = [];
        }
        if (!$.isArray(args)) {
            args = [args];
        }
        this.not('body, .scroll-wrapper').each(function () {
            var element = $(this),
                instance = element.data(browser.data.name);
            if (instance || command === 'init') {
                if (!instance) {
                    instance = new CustomScrollbar(element);
                }
                if (instance[command]) {
                    instance[command].apply(instance, args);
                }
            }
        });
        return this;
    };

    /**
     * Connect default options to global object
     */
    $.fn.scrollbar.options = defaults;


    /**
     * Check if scroll content/container size is changed
     */

    var updateScrollbars = (function () {
        var timer = 0,
            timerCounter = 0;

        return function (force) {
            var i, container, options, scroll, wrapper, scrollx, scrolly;
            for (i = 0; i < browser.scrolls.length; i++) {
                scroll = browser.scrolls[i];
                container = scroll.container;
                options = scroll.options;
                wrapper = scroll.wrapper;
                scrollx = scroll.scrollx;
                scrolly = scroll.scrolly;
                if (force || (options.autoUpdate && wrapper && wrapper.is(':visible') &&
                    (container.prop('scrollWidth') != scrollx.size || container.prop('scrollHeight') != scrolly.size || wrapper.width() != scrollx.visible || wrapper.height() != scrolly.visible))) {
                    scroll.init();

                    if (options.debug) {
                        window.console && console.log({
                            scrollHeight: container.prop('scrollHeight') + ':' + scroll.scrolly.size,
                            scrollWidth: container.prop('scrollWidth') + ':' + scroll.scrollx.size,
                            visibleHeight: wrapper.height() + ':' + scroll.scrolly.visible,
                            visibleWidth: wrapper.width() + ':' + scroll.scrollx.visible
                        }, true);
                        timerCounter++;
                    }
                }
            }
            if (debug && timerCounter > 10) {
                window.console && console.log('Scroll updates exceed 10');
                updateScrollbars = function () {
                };
            } else {
                clearTimeout(timer);
                timer = setTimeout(updateScrollbars, 300);
            }
        };
    })();

    /* ADDITIONAL FUNCTIONS */
    /**
     * Get native browser scrollbar size (height/width)
     *
     * @param {Boolean} actual size or CSS size, default - CSS size
     * @returns {Object} with height, width
     */
    function getBrowserScrollSize(actualSize) {

        if (browser.webkit && !actualSize) {
            return {
                height: 0,
                width: 0
            };
        }

        if (!browser.data.outer) {
            var css = {
                "border": "none",
                "box-sizing": "content-box",
                "height": "200px",
                "margin": "0",
                "padding": "0",
                "width": "200px"
            };
            browser.data.inner = $("<div>").css($.extend({}, css));
            browser.data.outer = $("<div>").css($.extend({
                "left": "-1000px",
                "overflow": "scroll",
                "position": "absolute",
                "top": "-1000px"
            }, css)).append(browser.data.inner).appendTo("body");
        }

        browser.data.outer.scrollLeft(1000).scrollTop(1000);

        return {
            // height: Math.ceil((browser.data.outer.offset().top - browser.data.inner.offset().top) || 0),
            height: 0,
            width: Math.ceil((browser.data.outer.offset().left - browser.data.inner.offset().left) || 0)
        };
    }

    /**
     * Check if native browser scrollbars overlay content
     *
     * @returns {Boolean}
     */
    function isScrollOverlaysContent() {
        var scrollSize = getBrowserScrollSize(true);
        return !(scrollSize.height || scrollSize.width);
    }

    function isVerticalScroll(event) {
        var e = event.originalEvent;
        if (e.axis && e.axis === e.HORIZONTAL_AXIS)
            return false;
        if (e.wheelDeltaX)
            return false;
        return true;
    }
})($ji); // custom scrollbar

(function ($) {
    $.fn.focusWithoutScrolling = function () {
        var x = window.scrollX, y = window.scrollY;
        this.focus();
        window.scrollTo(x, y);
    };
}($ji)); // jquery focus without scrolling

(function ($) {
    $.fn.textWidth = function () {
        var html_org = $(this).html();
        var html_calc = '<span>' + html_org + '</span>';
        $(this).html(html_calc);
        var width = $(this).find('span:first').width();
        $(this).html(html_org);
        return width;
    };
}($ji)); // text width

(function ($) {
    'use strict';
    $.focusNext = function () {
        selectNextTabbableOrFocusable(':focusable');
    };
    $.focusPrev = function () {
        selectPrevTabbableOrFocusable(':focusable');
    };
    $.tabNext = function () {
        selectNextTabbableOrFocusable(':tabbable');
    };
    $.tabPrev = function () {
        selectPrevTabbableOrFocusable(':tabbable');
    };
    function selectNextTabbableOrFocusable(selector) {
        var selectables = $(selector);
        var current = $(':focus');
        var nextIndex = 0;
        if (current.length === 1) {
            var currentIndex = selectables.index(current);
            if (currentIndex + 1 < selectables.length) {
                nextIndex = currentIndex + 1;
            }
        }
        selectables.eq(nextIndex).focus();
    }

    function selectPrevTabbableOrFocusable(selector) {
        var selectables = $(selector);
        var current = $(':focus');
        var prevIndex = selectables.length - 1;
        if (current.length === 1) {
            var currentIndex = selectables.index(current);
            if (currentIndex > 0) {
                prevIndex = currentIndex - 1;
            }
        }
        selectables.eq(prevIndex).focus();
    }

    $.extend($.expr[':'], {
        data: $.expr.createPseudo ?
            $.expr.createPseudo(function (dataName) {
                return function (elem) {
                    return !!$.data(elem, dataName);
                };
            }) :
            // support: jQuery <1.8
            function (elem, i, match) {
                return !!$.data(elem, match[3]);
            },
        focusable: function (element) {
            return focusable(element, !isNaN($.attr(element, 'tabindex')));
        },
        tabbable: function (element) {
            var tabIndex = $.attr(element, 'tabindex'),
                isTabIndexNaN = isNaN(tabIndex);
            return ( isTabIndexNaN || tabIndex >= 0 ) && focusable(element, !isTabIndexNaN);
        }
    });
    function focusable(element) {
        var map, mapName, img,
            nodeName = element.nodeName.toLowerCase(),
            isTabIndexNotNaN = !isNaN($.attr(element, 'tabindex'));
        if ('area' === nodeName) {
            map = element.parentNode;
            mapName = map.name;
            if (!element.href || !mapName || map.nodeName.toLowerCase() !== 'map') {
                return false;
            }
            img = $('img[usemap=#' + mapName + ']')[0];
            return !!img && visible(img);
        }
        return ( /^(input|select|textarea|button|object)$/.test(nodeName) ?
                !element.disabled :
                'a' === nodeName ?
                element.href || isTabIndexNotNaN :
                    isTabIndexNotNaN) &&
            // the element and all of its ancestors must be visible
            visible(element);

        function visible(element) {
            return $.expr.filters.visible(element) && !$(element).parents().addBack().filter(function () {
                    return $.css(this, 'visibility') === 'hidden';
                }).length;
        }
    }
})($ji); // focus next/prev tabable element

(function ($, window, document, undefined) {

    var pluginName = "textareaAutoSize";
    var pluginDataName = "plugin_" + pluginName;

    var containsText = function (value) {
        return (value.replace(/\s/g, '').length > 0);
    };

    function Plugin(element, options) {
        this.element = element;
        this.$element = $(element);
        this.init();
    }

    Plugin.prototype = {
        init: function () {
            var height = this.$element.outerHeight();
            var diff = parseInt(this.$element.css('paddingBottom')) +
                parseInt(this.$element.css('paddingTop')) || 0;

            if (containsText(this.element.value)) {
                this.$element.height(this.element.scrollHeight - diff);
            }

            // keyup is required for IE to properly reset height when deleting text
            this.$element.on('input keyup', function (event) {
                var $window = $(window);
                var currentScrollPosition = $window.scrollTop();

                $(this)
                    .height(0)
                    .height(this.scrollHeight - diff);

                $window.scrollTop(currentScrollPosition);
            });
        }
    };

    $.fn[pluginName] = function (options) {
        this.each(function () {
            if (!$.data(this, pluginDataName)) {
                $.data(this, pluginDataName, new Plugin(this, options));
            }
        });
        return this;
    };

})($ji, window, document);// textarea autoresize

(function ($) {
    $.fn.selectRange = function (start, end) {
        if (end === undefined) {
            end = start;
        }
        return this.each(function () {
            if ('selectionStart' in this) {
                this.selectionStart = start;
                this.selectionEnd = end;
            } else if (this.setSelectionRange) {
                this.setSelectionRange(start, end);
            } else if (this.createTextRange) {
                var range = this.createTextRange();
                range.collapse(true);
                range.moveEnd('character', end);
                range.moveStart('character', start);
                range.select();
            }
        });
    };
})($ji); // select range

(function ($) {
    $.fn.getCursorPosition = function () {
        var input = this.get(0);
        if (!input) return; // No (input) element found
        if ('selectionStart' in input) {
            // Standard-compliant browsers
            return input.selectionStart;
        } else if (document.selection) {
            // IE
            input.focus();
            var sel = document.selection.createRange();
            var selLen = document.selection.createRange().text.length;
            sel.moveStart('character', -input.value.length);
            return sel.text.length - selLen;
        }
    }
})($ji); // get cursor position

Singleton = {
    registry: {},
    get: function (classObj) {
        var classHash = String.prototype.hashCode(classObj.toString());
        if (!Singleton.registry[classHash]) {
            Singleton.registry[classHash] = new classObj();
        }

        return Singleton.registry[classHash];
    }
};

String.prototype.hashCode = function (str) {
    var hash = 0, i, chr, len;
    if (str.length === 0) return hash;
    for (i = 0, len = str.length; i < len; i++) {
        chr = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + chr;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
};